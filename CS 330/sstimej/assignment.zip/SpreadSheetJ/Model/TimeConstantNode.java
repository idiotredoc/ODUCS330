package SpreadSheetJ.Model;




public
class TimeConstantNode extends Expression
{
    private TimeValue value;
  
  public TimeConstantNode ()
  {
      value = new TimeValue(0,0,0,0);
  }

  public TimeConstantNode (String d)
  {
      int[] timeComponents = new int[4];
      parseTime (d, timeComponents);
      value = new TimeValue (timeComponents[0],
			     timeComponents[1],
			     timeComponents[2],
			     timeComponents[3]);
  }

    /**
     * Parse a time string returning 4 integers denoting days, hours
     * minutes, and seconds.
     *
     * @param s input string in format n:n, n:n:n, or n:n:n:n
     * @param values array of 4 ints, will be assigned the
     *    days, hours, minutes, seconds values from s
     */
    static void parseTime (String s, int[] values)
    {
	String[] parts = s.split(":");
	int days = 0;
	int hours = 0;
	int minutes = 0;
	int seconds = 0;
	seconds = Integer.parseInt(parts[parts.length - 1]);
	if (parts.length > 1)
	    minutes = Integer.parseInt(parts[parts.length - 2]);
	if (parts.length > 2)
	    hours = Integer.parseInt(parts[parts.length - 3]);
	if (parts.length > 3)
	    days = Integer.parseInt(parts[0]);
	
	values[0] = days;
	values[1] = hours;
	values[2] = minutes;
	values[3] = seconds;
    }

  // How many operands does this expression node have?
  public int arity()                    {return 0;}

  // Get the k_th operand
  public Expression operand(int k)      {return null;}
    //pre: k < arity()


  // Evaluate this expression
    public Value evaluate(SpreadSheet s)  {return (TimeValue)value.clone();}



  // Copy this expression (deep copy), altering any cell references
  // by the indicated offsets except where the row or column is "fixed"
  // by a preceding $. E.g., if e is  2*D4+C$2/$A$1, then
  // e.copy(1,2) is 2*E6+D$2/$A$1, e.copy(-1,4) is 2*C8+B$2/$A$1
  public Expression clone (int colOffset, int rowOffset)
  {
      TimeConstantNode theClone = new TimeConstantNode();
      theClone.value = value;
      return theClone;
  }


  // The following control how the expression gets printed by 
  // the default implementation of put(ostream&)

  public boolean isInline()      {return true;}
  // if false, print as functionName(comma-separated-list)
  // if true, print in inline form

  public int precedence()        {return 1000;}
  // Parentheses are placed around an expression whenever its precedence
  // is lower than the precedence of an operator (expression) applied to it.
  // E.g., * has higher precedence than +, so we print 3*(a1+1) but not
  // (3*a1)+1

  public String getOperator()    {return "" + value;}
  // Returns the name of the operator for printing purposes.
  // For constants, this is the string version of the constant value.


}
